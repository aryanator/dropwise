from .predictor import DropwisePredictor

__all__ = ["DropwisePredictor"]
